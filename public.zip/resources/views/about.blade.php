@extends('master')
@section('title')
About
@endsection


