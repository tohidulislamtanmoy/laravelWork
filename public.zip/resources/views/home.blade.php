@extends('master')
@section('title')
Home
@endsection

@section('form-data')
<h4 class="text-center" style="padding-top: 50px "> Student Data</h4>
<form action="" method="POST" class="shadow" enctype="multipart/form-data" style="width:50%; margin:62px auto; padding:50px    30px">
    <div class="mb-3">
      <label for="name" class="form-label">Name</label>
      <input type="text" class="form-control" id="name">
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" id="email">
    </div>

    <div class="mb-3">
        <label for="pass" class="form-label">Password</label>
        <input type="password" class="form-control" id="pass">
      </div>

      <div class="mb-3">
        <label for="image" class="form-label">Image</label>
        <input type="file" class="form-control" id="image">
      </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
@endsection

