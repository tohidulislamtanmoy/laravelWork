@extends('master')

@section('title')
Contact
@endsection
@section('page-titel')
   <h1>This is our Home page</h1>
   <span>My Name is</span>

    @foreach ($product as $value )

        <p> product name: {{ $value['ptype'] }};</p>
        <p> product Brand: {{ $value['beand'] }}; </p>
        <p>product price : {{ $value['price'] }};</p>
        <p> {{ $value['pWarrenty'] }}; </p> <hr>



    @endforeach


@endsection
