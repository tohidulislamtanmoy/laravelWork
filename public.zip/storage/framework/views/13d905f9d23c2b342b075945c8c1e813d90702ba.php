<?php $__env->startSection('title'); ?>
Service
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tohidul-11\laravelBlog\resources\views/service.blade.php ENDPATH**/ ?>