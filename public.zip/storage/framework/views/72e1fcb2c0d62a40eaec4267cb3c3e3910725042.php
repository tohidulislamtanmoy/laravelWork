<?php $__env->startSection('title'); ?>
Contact
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-titel'); ?>
   <h1>This is our Home page</h1>
   <span>My Name is</span>

    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <p> product name: <?php echo e($value['ptype']); ?>;</p>
        <p> product Brand: <?php echo e($value['beand']); ?>; </p>
        <p>product price : <?php echo e($value['price']); ?>;</p>
        <p> <?php echo e($value['pWarrenty']); ?>; </p> <hr>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tohidul-11\laravelBlog\resources\views/contact.blade.php ENDPATH**/ ?>