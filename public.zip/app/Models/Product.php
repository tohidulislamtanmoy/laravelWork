<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    use HasFactory;

    public static function allData(){
        return [
            0 => [
                'ptype' => 'sunglass',
                'beand' => 'Ray-Ban',
                'price' => '100 USD',
                'pWarrenty' => 'N/A',
            ],
            1 => [
                'ptype' => 'Mobil',
                'beand' => 'Apply',
                'price' => '500 USD',
                'pWarrenty' => 'N/A',
            ],
            2 => [
                'ptype' => 'shirt',
                'beand' => 'cosy',
                'price' => '1500 USD',
                'pWarrenty' => 'N/A',
            ],

        ];
    }
}
