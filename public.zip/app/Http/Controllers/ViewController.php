<?php

namespace App\Http\Controllers;
 use App\Models\Product;
use Illuminate\Http\Request;

class ViewController extends Controller
{
public function index(){
    $name = [
        'fName' => 'Tohidul',
        'lName' => 'islam',
    ];

    return view('home');
}
public function about(){
    return view('about');
}
public function service(){
    return view('service');
}
public function contact(){
    $allProduct = Product::allData();
    return view('contact',['product' => $allProduct ]);


    // return view('contact');
}
}
